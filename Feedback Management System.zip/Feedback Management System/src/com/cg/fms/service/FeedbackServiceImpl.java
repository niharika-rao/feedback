package com.cg.fms.service;

import java.util.ArrayList;

import com.cg.fms.bean.Feedback;
import com.cg.fms.dao.FeedbackDAOImpl;
import com.cg.fms.dao.IFeedbackDAO;
import com.cg.fms.exception.FMSException;


public class FeedbackServiceImpl implements IFeedbackService {

	IFeedbackDAO dao = new FeedbackDAOImpl();
	
	@Override
	public ArrayList<Feedback> viewTrainingProgramReport(int month) throws FMSException {

		return dao.viewTrainingProgramReport(month);		
	}
	@Override
	public float findMonthlyAverage(int month) throws FMSException {
		
		return dao.findMonthlyAverage(month);
	}
	@Override
	public ArrayList<Feedback> viewGeneralFeedback() throws FMSException {
		// TODO Auto-generated method stub
		return dao.viewGeneralFeedback();
	}
	@Override
	public ArrayList<Feedback> viewFacultyProgramReport(int month) throws FMSException {
		// TODO Auto-generated method stub
		return dao.viewFacultyProgramReport(month);
	}

}
