package com.cg.fms.service;

import com.cg.fms.bean.Employee;
import com.cg.fms.bean.Feedback;
import com.cg.fms.dao.IParticipantDAO;
import com.cg.fms.dao.ParticipantDAOImpl;
import com.cg.fms.exception.FMSException;

public class ParticipantServiceImpl implements IParticipantService {

	IParticipantDAO dao = new ParticipantDAOImpl();
	public int provideFeedback(Employee employee, Feedback feed) throws FMSException {
		
		 return dao.provideFeedback(employee,feed);
		
	}
	@Override
	public boolean checkFeedbackValue(String str) {
		for(int i=0;i<str.length();i++){
			if(!Character.isDigit(str.charAt(i)))
				return false;
		}
		int feedback = Integer.parseInt(str);
		if(feedback<0 || feedback>5){
			return false;
		}
			return true;
	}
	
	
}
