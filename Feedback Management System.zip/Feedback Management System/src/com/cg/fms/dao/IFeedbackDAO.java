package com.cg.fms.dao;

import java.util.ArrayList;

import com.cg.fms.bean.Feedback;
import com.cg.fms.exception.FMSException;

public interface IFeedbackDAO {
	
	public ArrayList<Feedback> viewTrainingProgramReport(int month) throws FMSException;
	
	public float findMonthlyAverage(int month) throws FMSException;
	
	public ArrayList<Feedback> viewGeneralFeedback() throws FMSException;
	
	public ArrayList<Feedback> viewFacultyProgramReport(int month) throws FMSException;
}
