package com.cg.fms.dao;

import java.util.ArrayList;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.Employee;
import com.cg.fms.bean.FacultySkill;
import com.cg.fms.bean.TrainingProgram;
import com.cg.fms.exception.FMSException;

public interface ICoordinatorDAO {

	
	int participantEnroll(int trainingCode, int employeeID) throws FMSException;
	
	ArrayList<TrainingProgram> viewTrainingList() throws FMSException;
	
	ArrayList<CourseMaster> viewCourseList() throws FMSException;
	
	ArrayList<FacultySkill> viewFacultyList() throws FMSException;
	
	ArrayList<TrainingProgram> viewTrainings() throws FMSException;
	
	int deleteTraining(TrainingProgram training) throws FMSException;
	
	ArrayList<Employee> viewParticipantList() throws FMSException;
	
	int addNewTraining(TrainingProgram training) throws FMSException;
	
	boolean checkIfValid(int trainingCode, int employeeID) throws FMSException;
}
