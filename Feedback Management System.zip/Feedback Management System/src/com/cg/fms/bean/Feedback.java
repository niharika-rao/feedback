package com.cg.fms.bean;

import java.sql.Date;

public class Feedback {

	int trainingCode;
	int participantID;
	int fbPrsComm;
	int fbClrfyDbts;
	int fbTm;
	int fbHandout;
	int fbHwSwNtwk;
	String comments;
	String suggestions;
	Date entryDate;
	
	String employeeName;
	
	
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	
	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public int getParticipantID() {
		return participantID;
	}
	public void setParticipantID(int participantID) {
		this.participantID = participantID;
	}
	public int getFbPrsComm() {
		return fbPrsComm;
	}
	public void setFbPrsComm(int fbPrsComm) {
		this.fbPrsComm = fbPrsComm;
	}
	public int getFbClrfyDbts() {
		return fbClrfyDbts;
	}
	public void setFbClrfyDbts(int fbClrfyDbts) {
		this.fbClrfyDbts = fbClrfyDbts;
	}
	public int getFbTm() {
		return fbTm;
	}
	public void setFbTm(int fbTm) {
		this.fbTm = fbTm;
	}
	public int getFbHandout() {
		return fbHandout;
	}
	public void setFbHandout(int fbHandout) {
		this.fbHandout = fbHandout;
	}
	public int getFbHwSwNtwk() {
		return fbHwSwNtwk;
	}
	public void setFbHwSwNtwk(int fbHwSwNtwk) {
		this.fbHwSwNtwk = fbHwSwNtwk;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
	public Date getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}
	
	
}
